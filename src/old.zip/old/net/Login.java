/*
 * Login.java
 *
 * Created on 24. Oktober 2007, 14:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.1.0
 *
 */

public class Login {
    
    private final String user;
    private final String pass;
    
    public Login(String user, String pass) {
        this.user = user;
        this.pass = pass;
    }
    
    public Login(String user) {
        this(user, "");
    }
    
    public String getUser() {
        return user;
    }
    
    public String getPass() {
        return pass;
    }
    
}
