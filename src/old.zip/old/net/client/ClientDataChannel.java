/*
 * ClientDataChannel.java
 *
 * Created on 23. Dezember 2008, 03:05
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.client;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.*;
import java.util.ArrayList;
import net.AbstractDataChannel;
import io.IOable;

public class ClientDataChannel extends AbstractDataChannel {
    
    public ClientDataChannel() {}
    
    public ArrayList getTextList() throws IOException {
        BufferedReader in = super.getSource().getTextReader();
        ArrayList list = new ArrayList();
        try {
            Thread.sleep(500); // wartet auf Daten
            while ( in.ready() ) {
                list.add( in.readLine() );
                Thread.sleep(20);
            }
            try {
                in.close();
                super.close();
            }
            catch (IOException e) { e.printStackTrace(); }
        }
        catch (InterruptedException e) {}
        return list;
    }
    
}
