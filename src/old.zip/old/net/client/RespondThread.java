/*
 * RespondThread.java
 *
 * Created on 10. Februar 2008, 20:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.client;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.0.0
 *
 */

import java.io.*;

public class RespondThread extends Thread {
    
    private ClientProtocolChannel channel;
    
    public RespondThread(ClientProtocolChannel channel) {
        this.channel = channel;
    }
    
    public void run() {
        try {
            do {
                channel.processIncommingMessage( channel.readLine() );
                Thread.sleep(20);
            } while ( !isInterrupted() && channel.isOnline() );
        }
        catch (IOException e) {
            e.printStackTrace();
            interrupt();
        }
        catch (InterruptedException e) { interrupt(); }
    }
    
}
