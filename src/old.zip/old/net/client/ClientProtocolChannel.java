/*
 * ClientProtocolChannel.java
 *
 * Created on 6. November 2006, 22:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.client;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import net.*;
import java.io.*;
import java.net.Socket;
import io.Notifyable;

public class ClientProtocolChannel extends AbstractProtocolChannel implements Closeable, Notifyable {
    
    private final Object O = new Object();
    private String currentMessage;
    private RespondThread responder;
    private ServiceAddressContainer container;
    
    public ClientProtocolChannel(ServiceAddressContainer container) {
        this(container, false);
    }
    
    public ClientProtocolChannel(ServiceAddressContainer container, boolean autoconnect) {
        this.container = container;
        if (autoconnect)
            connect();
    }
    
    public Socket getSocket() throws IOException {
        return container.getSocket();
    }
    
    public Object getSyncObject() {
        return O;
    }
    
    public String getCurrentMessage() {
        return currentMessage;
    }
    
    public synchronized void processIncommingMessage(String message) {
        this.currentMessage = message;
        synchronized ( getSyncObject() ) { getSyncObject().notify(); }
    }
    
    public boolean connect() {
        boolean value = false;
        responder = new RespondThread(this);
        synchronized ( getSyncObject() ) {
            try {
                value = super.connect();
                responder.start();
                getSyncObject().wait();
            }
            catch (InterruptedException e) {}
        }
        return value;
    }
    
    public void sendLine(String s) {
        synchronized ( getSyncObject() ) {
            try {
                super.sendLine(s);
                getSyncObject().wait();
            }
            catch (InterruptedException e) {}
        }
    }
    
    public void close() {
        responder.interrupt();
        super.close();
    }
    
}
