/*
 * DataChannel.java
 *
 * Created on 5. November 2009, 04:10
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import io.IOable;

public class DataChannel extends AbstractDataChannel {
    
    public DataChannel() {}
    
    public DataChannel(IOable source, IOable target) {
        super.setSource(source);
        super.setTarget(target);
    }
    
}
