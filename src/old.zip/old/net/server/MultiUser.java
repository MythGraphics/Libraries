/*
 *
 */

package net.server;

/**
 *
 * @author  Martin Pröhl alias MythGraphics
 * @version 2.0.0
 *
 */

public class MultiUser {

    private MultiUser() {}

    public static User[] getMultiUser(String[] names, String[] pws, String[] pathes) {
        User[] users = new User[names.length];
        for ( int i = 0; i < names.length; ++i ) {
            users[i] = new User( names[i], pws[i], pathes[i] );
        }
        return users;
    }

    public static User getUser(User[] users, String name) {
        for ( int i = 0; i < users.length; ++i ) {
            if ( users[i].getName().equals( name ))
                return users[i];
        }
        return null;
    }

}
