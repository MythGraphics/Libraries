/*
 *
 */

package net.server;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.IOException;
import java.net.ServerSocket;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.Softshutdownable;
import net.util.ProtocolStatics;

public abstract class AbstractServer implements Runnable, Softshutdownable {

    public final static int STANDARD_TIMEOUT = 30*1000;
    public final static int INFINITE_TIMEOUT = 0;

    private boolean interrupted = false;
    private ExecutorService executor;
    private ServerSocket ss;

    abstract int getServerPort() throws SocketException;
    abstract ServerProtocol getServerProtocol(ServerSocket ss) throws IOException;

    private void close() {
        try { ss.close(); }
        catch (IOException e) { e.printStackTrace(); }
    }

    @Override
    public void shutdown() {
        shutdown(0);
    }

    @Override
    public void shutdown(final long timeout) {
        // timeout in ms befor hard shutdown
        final long intervall = 200;
        System.out.println( "Server-Thread-Pool shutdown initiated" );
        System.out.println( "Hard shutdown in " + (timeout/1000.0) + " seconds" );
        interrupt();
        try { Thread.sleep( intervall ); }
        catch (InterruptedException e) {}
        close();
        executor.shutdown();
        new Thread() {
            @Override
            public void run() {
                for ( long counter = 0; counter <= timeout; counter += intervall )
                    try { Thread.sleep( intervall ); }
                    catch (InterruptedException e) {}
                if ( !executor.isTerminated() ) {
                    System.out.println( "Hard shutdown now" );
                    executor.shutdownNow();
                }
            }
        }.start();
    }

    private void interrupt() {
        interrupted = true;
    }

    public boolean isInterrupted() {
        return interrupted;
    }

    @Override
    public void run() {
        executor = Executors.newCachedThreadPool();
        try {
            // ServerSocket erstellen
            ss = new ServerSocket( getServerPort() );
            ss.setSoTimeout( INFINITE_TIMEOUT );
        }
        catch (IOException e) {
            System.out.println( "Server could not be established" );
            System.out.println( "Creating ServerSocket failed" );
            e.printStackTrace();
            return;
        }
        while ( !isInterrupted() ) {
            try {
                executor.execute( getServerProtocol(ss) );
                System.out.println( ProtocolStatics.DEBUG + "Connection recieved" );
                System.out.println( ProtocolStatics.DEBUG + "New Thread from Thread-Pool started" );
            }
            catch (SocketException se) { se.printStackTrace(); }
            catch (IOException ioe) { ioe.printStackTrace(); }
        }
    }

}
