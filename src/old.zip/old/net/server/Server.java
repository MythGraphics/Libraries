/*
 *
 */

package net.server;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.IOException;
import java.net.ServerSocket;

public class Server extends AbstractServer {

    private final int port;
    private final User[] users;

    public Server(ServerProtocol protocol, int port, User[] users) {
        this.port   = port;
        this.users  = users;
    }

    @Override
    public int getServerPort() {
        return port;
    }

    public User[] getMultiUserSpace() {
        return users;
    }

    @Override
    public ServerProtocol getServerProtocol(ServerSocket ss) throws IOException {
        return new ServerProtocol( ss.accept(), getMultiUserSpace() );
    }

    public void start() {
        new Thread(this).start();
    }

}
