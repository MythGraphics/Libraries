/*
 *
 */

package net.server;

/**
 *
 * @author  Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.File;

public class User {

    private final String name;
    private final String pw;
    private final String path;

    private String subpath = "/";
    private boolean nameOK = false;
    private boolean pwOK = false;

    public User(String name, String pw, String path) {
        this.name   = name;
        this.pw     = pw;
        this.path   = path;                                                                         // file system path
    }

    public File getPath() {
        return new File( path + subpath );
    }

    public String getSubPath() {
        return subpath;
    }

    public void addSubPath(String subpath) {
        this.subpath += subpath;
    }

    public String getName() {
        return name;
    }

    public void checkName(String name) {
        this.nameOK = this.name.equals(name);
    }

    public void checkPass(String pw) {
        this.pwOK = this.pw.equals(pw);
    }

    public boolean isLoginOK() {
        return nameOK && pwOK;
    }

}
