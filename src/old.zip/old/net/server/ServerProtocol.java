/*
 *
 */

package net.server;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.IOException;
import java.net.Socket;
import net.ftp.AbstractServerProtocol;

public class ServerProtocol extends AbstractServerProtocol implements Runnable {

    private final Socket socket;
    private final User[] users;

    public ServerProtocol(Socket socket, User[] users) {
        this.socket = socket;
        this.users  = users;
    }

    @Override
    public User getUser(String name) {
        return MultiUser.getUser(users, name);
    }

    @Override
    public Socket getSocket() {
        return socket;
    }

    public void sendLine(int code, String message) {
        super.sendLine( code + " " + message );
    }

    private void initConnection() {
        super.connect();
    }

    @Override
    public void run() {
        initConnection();
        super.sendLine( AbstractServerProtocol.WELCOME );
        try {
            while ( super.isOnline() ) {
                handleInput();
                try { Thread.sleep(20); }
                catch (InterruptedException e) {}
                super.run();
            }
        }
        catch (IOException e) { e.printStackTrace(); }
        finally { super.close(); }
    }

}
