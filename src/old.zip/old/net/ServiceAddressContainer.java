/*
 * ServiceAddressContainer.java
 *
 * Created on 18. Mai 2007, 14:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.0.1
 *
 */

import java.io.IOException;
import java.net.Socket;
import java.util.*;

public class ServiceAddressContainer {
    
    public final static int STANDARD_TIMEOUT = 30*1000;
    private final String address;
    private final int port;
    private int timeout = STANDARD_TIMEOUT;
    
    public ServiceAddressContainer(String address, int port) {
        this.address = address;
        this.port = port;
    }
    
    public ServiceAddressContainer(String str) throws NoSuchElementException, NumberFormatException {
        StringTokenizer tokenizer = new StringTokenizer(str, ":", false);
        address = tokenizer.nextToken();
        port = Integer.parseInt( tokenizer.nextToken() );
        timeout = STANDARD_TIMEOUT;
    }
    
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
    
    public Socket getSocket() throws IOException {
        Socket s = new Socket(address, port);
        s.setSoTimeout(timeout);
        return s;
    }
    
    public String getAddress() {
        return address;
    }
    
    public int getPort() {
        return port;
    }
    
    public String toString() {
        return address + ":" + port;
    }
    
}
