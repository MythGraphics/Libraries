/*
 * AbstractDataChannel.java
 *
 * Created on 6. November 2006, 22:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.0.0
 *
 */

import io.IOable;
import io.AbstractDataTransfere;

public abstract class AbstractDataChannel extends AbstractDataTransfere {
    
    private IOable source, target;
    
    public IOable getSource() {
        return source;
    }
    
    public IOable getTarget() {
        return target;
    }
    
    public void setSource(IOable source) {
        this.source = source;
    }
    
    public void setTarget(IOable target) {
        this.target = target;
    }
    
}
