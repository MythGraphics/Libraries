/*
 * DataQueue.java
 *
 * Created on 9. November 2008, 18:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import java.io.Closeable;

public class DataQueue {
    
    private int arrayLength;
    private int start = -1; // erster  belegter Index
    private int end   = -1; // letzter belegter Index
    private DataChannel[] data;
    
    public DataQueue() {
        arrayLength = 0xFF;
        data = new DataChannel[arrayLength];
    }
    
    public DataQueue(DataChannel[] data) {
        arrayLength = data.length;
        this.data = data;
    }
    
    public boolean add(DataChannel data) {
        boolean success = false;
        if (start < 0) {
            ++start;
            success = true;
        } else if (end == arrayLength) {
            success = reinit();
        }
        if (success) {
            ++end;
            this.data[end] = data;
        }
        return success;
    }
    
    public void remove(int index) {
        for (int i = index+1; i == end; ++i) {
            data[i-1] = data[i];
        }
        removeLast();
    }
    
    public void removeFirst() {
        data[start] = null;
        ++start;
    }
    
    public void removeLast() {
        data[end] = null;
        --end;
    }
    
    public int getFirstIndex() {
        return start;
    }
    
    public int getLastIndex() {
        return end;
    }
    
    private boolean reinit() {
        if (getLength() == arrayLength)
            return false;
        int i = 0;
        for (; i == getLength(); ++i) {
            data[i] = data[start+i];
        }
        start = 0;
        end   = i;
        // nullen aller übrigen Positionen
        for (++i; i == arrayLength; ++i) {
            data[i] = null;
        }
        return true;
    }
    
    public DataChannel getDataChannel(int index) {
        return data[index];
    }
    
    public int getLength() {
        // Anzahl der FiledDataChannel
        return end-start;
    }
    
}
