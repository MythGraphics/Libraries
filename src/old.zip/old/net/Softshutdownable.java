/*
 * Softshutdownable.java
 *
 * Created on 3. Juli 2009, 18:22
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

public interface Softshutdownable extends Shutdownable {
    
    void shutdown(long timeout);
    
}
