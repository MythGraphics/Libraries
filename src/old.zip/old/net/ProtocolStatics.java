/*
 * ProtocolStatics.java
 *
 * Created on 16. Dezember 2009, 19:44
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

public class ProtocolStatics {
    
    public final static String INCOMMING = "<--  ";
    public final static String OUTGOING  = " --> ";
    public final static String MESSAGE   = " --  ";
    public final static String DEBUG     = "     ";
    
    private ProtocolStatics() {}
    
}
