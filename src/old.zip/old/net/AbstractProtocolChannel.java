/*
 * AbstractProtocolChannel.java
 *
 * Created on 5. November 2009, 03:12
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.0.0
 *
 */

import java.io.*;
import java.net.*;

public abstract class AbstractProtocolChannel implements Closeable {
    
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String address;
    private boolean online = false;
    
    public abstract Socket getSocket() throws IOException;
    
    public boolean connect() {
        try {
            socket = getSocket();
            address = socket.getInetAddress().getHostAddress() + " ";
            System.out.println("Protocol-Connection established");
            in  = io.Reader.getTextReader(socket);
            out = io.Writer.getTextWriter(socket);
            System.out.println("Protocol-I/O-Streams established");
            online = true;
            return true;
        }
        catch (IOException e) {
            e.printStackTrace();
            close();
            return false;
        }
    }
    
    public String readLine() throws IOException {
        String s = in.readLine();
        System.out.println(address + ProtocolStatics.INCOMMING + s);
        return s;
    }
    
    public void sendLine(String s) {
        synchronized (this) {
            out.println(s);
            System.out.println(address + ProtocolStatics.OUTGOING + s);
        }
        out.flush();
    }
    
    public void close() {
        try {
            in.close();
            out.close();
            System.out.println("Protocol-I/O-Streams terminated");
        }
        catch (IOException e) { e.printStackTrace(); }
        try {
            socket.close();
            System.out.println("Protocol-Connection terminated");
            
            /* wartet, damit der Socket komplett geschlossen werden kann und seine Ressourcen
             * vollständig an das System zurückgegeben werden können
             */
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
        catch (IOException e) { e.printStackTrace(); }
        online = false;
    }
    
    public boolean isOnline() {
        return online;
    }
    
    public void setOffline() {
        online = false;
    }
    
}
