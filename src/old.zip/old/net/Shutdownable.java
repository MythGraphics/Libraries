/*
 * Shutdownable.java
 *
 * Created on 28. Dezember 2008, 17:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

public interface Shutdownable {
    
    void shutdown();
    
}
