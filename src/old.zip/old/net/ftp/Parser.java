/*
 * Parser.java
 *
 * Created on 9. Dezember 2007, 15:17
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.ftp;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.1.1
 *
 */

import net.Login;
import net.ServiceAddressContainer;
import java.util.StringTokenizer;

public class Parser {
    
    public static ServiceAddressContainer getNetworkContainer(String s) {
        s = net.util.Parser.removeProtocolTag(s);
        if ( s.contains("@") ) {
            s = s.substring( s.indexOf('@')+1 );
        }
        if ( s.contains(":") ) {
            StringTokenizer tokenizer = new StringTokenizer(s, ":", false);
            return new ServiceAddressContainer( tokenizer.nextToken(), Integer.parseInt( tokenizer.nextToken() ));
        } else
           return null;
    }
    
    public static Login getLogin(String s) {
        s = net.util.Parser.removeProtocolTag(s);
        if ( s.contains("@") ) {
            StringTokenizer tokenizer = new StringTokenizer(s, ":@", false);
            return new Login( tokenizer.nextToken(), tokenizer.nextToken() );
        } else
            return null;
    }
    
}
