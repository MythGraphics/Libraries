/*
 * ClientProtocol.java
 *
 * Created on 24. Oktober 2007, 15:49
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.ftp;

/*
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 4.2.1
 *
 */

import io.*;
import net.*;
import net.client.*;
import java.io.*;
import java.net.*;
import java.util.StringTokenizer;
import java.util.ArrayList;
import net.util.IPAddress;

public class ClientProtocol extends ClientProtocolChannel {
    
    public final static int STANDARD_PROTOCOL_PORT    = 21;
    public final static int STANDARD_DATA_ACTIVE_PORT = 20;
    public final static int INTERNAL_DATA_ACTIVE_PORT = 2020;
    public final static String PREVIOUS_DIR = "../";
    
    public PipedWriter progressWriter;
    
    private boolean passive   = true;
    private boolean connected = false;
    private boolean loggedIn  = false;
    private boolean userOK    = false;
    private boolean passOK    = false;
    private int port = INTERNAL_DATA_ACTIVE_PORT;
    private Login login;
    private String publicIPAddress;
    
    public ClientProtocol(ServiceAddressContainer container, Login login) throws IOException {
        super(container);
        this.login = login;
    }
    
    public void disconnect() throws IOException {
        if ( getCurrentMessageCode() != 421 ) {
            super.sendLine("QUIT");
            // Antwort-Code: 221
        }
        loggedIn = false;
        connected = false;
        super.close();
    }
    
    public boolean connect() {
        if ( super.connect() ) {
            try { Thread.sleep(500); } // wartet auf mögliche Welcome-Message oder Ähnliches
            catch (InterruptedException e) {}
            if ( getCurrentMessageCode() == 220 )
                connected = true;
            else
                connected = false;
        }
        return connected;
    }
    
    public boolean isConnected() {
        return connected;
    }
    
    public int getCurrentMessageCode() {
        return Integer.parseInt( super.getCurrentMessage().substring(0, 3) );
    }
    
    public boolean logMeIn() {
        super.sendLine( "USER " + login.getUser() );
        if ( getCurrentMessageCode() == 331 ) {
            userOK = true;
            super.sendLine( "PASS " + login.getPass() );
        } else {
            userOK = false;
            return false;
        }
        if ( getCurrentMessageCode() == 230 ) {
            passOK = true;
            loggedIn = true;
            return true;
        } else {
            passOK = false;
            return false;
        }
    }
    
    public void setPassiveTransmission() {
        passive = true;
    }
    
    public void setActiveTransmission(int port) {
        passive = false;
        this.port = port;
    }
    
    public Object[] getFileList() throws IOException {
        if ( !setAsciiType() )
            return new String[] {PREVIOUS_DIR};
        ClientDataChannel data = generateDataChannel();
        super.sendLine("NLST");
        if ( getCurrentMessageCode() != 150 )
            return new String[] {PREVIOUS_DIR};
        ArrayList list = data.getTextList();
        if ( getCurrentMessageCode() != 226 )
            return new String[] {PREVIOUS_DIR};
        list.add(0, PREVIOUS_DIR);
        list.trimToSize();
        return list.toArray();
    }
    
    private SocketIO setActiveMode() throws IOException {
        byte portByte1 = (byte) (port >>> 8);
        byte portByte2 = (byte) port;
        String portString = "," + String.valueOf(portByte1) + "," + String.valueOf(portByte2);
        if (publicIPAddress == null)
            publicIPAddress = IPAddress.getPublicIPAddress();
        String portCommandString = publicIPAddress.replace(".", ",") + portString;
        super.sendLine("PORT " + portCommandString);
        if ( getCurrentMessageCode() == 200 )
            return new SocketIO(port);
        else
            return null;
    }
    
    private SocketIO setPassiveMode() throws IOException {
        super.sendLine("PASV");
        if ( getCurrentMessageCode() == 227 ) {
            StringBuffer ip;
            StringTokenizer tokenizer = new StringTokenizer( getCurrentMessage(), "(),", false );
            tokenizer.nextToken();
            ip = new StringBuffer( tokenizer.nextToken() );
            ip.append(".");
            ip.append( tokenizer.nextToken() );
            ip.append(".");
            ip.append( tokenizer.nextToken() );
            ip.append(".");
            ip.append( tokenizer.nextToken() );
            String dataIp = String.valueOf(ip);
            int dataPort = Integer.parseInt( tokenizer.nextToken() ) << 8 |
                           Integer.parseInt( tokenizer.nextToken() );
            return new SocketIO( new ServiceAddressContainer(dataIp, dataPort).getSocket() );
        } else
            return null;
    }
    
    public boolean changeDir(String dir) {
        super.sendLine("CWD " + dir);
        if ( getCurrentMessageCode() == 250 )
            return true;
        else
            return false;
    }
    
    public boolean setAsciiType() {
        super.sendLine("TYPE A");
        if ( getCurrentMessageCode() == 200 )
            return true;
        else
            return false;
    }
    
    public boolean setBinaryType() {
        super.sendLine("TYPE I");
        if ( getCurrentMessageCode() == 200 )
            return true;
        else
            return false;
    }
    
    public boolean isLoggedIn() {
        return loggedIn;
    }
    
    public boolean rename(String oldName, String newName) {
        super.sendLine("RNFR " + oldName);
        if ( getCurrentMessageCode() == 350 ) {
            super.sendLine("RNTO " + newName);
        } else
            return false;
        if ( getCurrentMessageCode() == 250 )
            return true;
        else
            return false;
    }
    
    public boolean noop() {
        // NOOP --> NoOp --> No-Operation
        super.sendLine("NOOP");
        if ( getCurrentMessageCode() == 200 )
            return true;
        else
            return false;
    }
    
    public boolean deleteFile(String filename) {
        super.sendLine("DELE " + filename);
        if ( getCurrentMessageCode() == 250 )
            return true;
        else
            return false;
    }
    
    public long getFileSize(String filename) {
        super.sendLine("SIZE " + filename);
        if ( getCurrentMessageCode() == 213 ) {
            StringTokenizer tokenizer = new StringTokenizer( getCurrentMessage(), " ", false );
            tokenizer.nextToken();
            return Long.parseLong( tokenizer.nextToken() );
        } else
            return -1;
    }
    
    public boolean getFile(String sourceFilename, File targetFile) throws IOException {
        ClientDataChannel data = generateDataChannel();
        data.setTarget( new FileIO(targetFile) );
        data.transfere(data.GET);
        super.sendLine("RETR " + sourceFilename);
        return verifyTransfere( data.getSyncObject() );
    }
    
    public boolean sendFile(String targetFilename, File sourceFile) throws IOException {
        ClientDataChannel data = generateDataChannel();
        data.setTarget( new FileIO(sourceFile) );
        data.transfere(data.PUT);
        super.sendLine("STOR " + targetFilename);
        return verifyTransfere( data.getSyncObject() );
    }
    
    private ClientDataChannel generateDataChannel() throws IOException {
        ClientDataChannel data = new ClientDataChannel();
        if (passive)
            data.setTarget( setPassiveMode() );
        else
            data.setTarget( setActiveMode() );
        if (data != null) {
            System.out.println("Data-Connection successfully established");
            progressWriter = data.getProgressWriter();
        } else
            System.err.println("Unable to establish Data-Connection");
        return data;
    }
    
    private boolean verifyTransfere(Object sync) {
        boolean value;
        if ( getCurrentMessageCode() == 150 )
            value = true;
        else
            value = false;
        synchronized (sync) {
            try { sync.wait(); }
            catch (InterruptedException e) {}
        }
        return value;
    }
    
}
