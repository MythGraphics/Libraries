/*
 * ServerProtocol.java
 *
 * Created on 17. April 2008, 21:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.ftp;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 2.0.0
 *
 * File Transfere Protocol - Test-Version, only a few commands implemented
 *
 */

import net.*;
import net.server.AbstractServerProtocol;
import net.server.ServerProtocolChannel;
import java.util.StringTokenizer;

public class ServerProtocol extends AbstractServerProtocol {
    
    public final static int STANDARD_PORT = 21;
    public final static String NAME       = "MythGraphics FTP-Implementierung";
    public final static String VERSION    = "v2.0.0";
    
    private final Login[] logins;
    
    private int userindex = -1;
    private String user;
    private ServerProtocolChannel channel;
    
    /*
    public ServerProtocol(ServerProtocolChannel channel, Login[] logins) {
        this.channel = channel;
        this.logins = logins;
    }
     */
    
    public ServerProtocol(Login[] logins) {
        this.logins = logins;
    }
    
    public Runnable getServerProtocol(ServerProtocolChannel channel) {
        this.channel = channel;
        return this;
    }
    
    public ServerProtocolChannel getServerProtocolChannel() {
        return channel;
    }
    
    private boolean isValidUser(String user) {
        for (int i = 0; i < logins.length; ++i) {
            if ( user.equals( logins[i].getUser() )) {
                userindex = i;
                return true;
            }
        }
        return false;
    }
    
    private boolean isValidPass(String pass) {
        if ( pass.equals(logins[userindex].getPass() ))
            return true;
        else
            return false;
    }
    
    public void processIncommingMessage(String message) {
        StringTokenizer t = new StringTokenizer(message, " -", false);
        if ( message.contains(" ") )
            message = t.nextToken();
        
        if ( message.equalsIgnoreCase("QUIT") ) {
            channel.sendLine(221, "Bye bye");
            channel.setOffline();
            return;
        } else if ( message.equalsIgnoreCase("USER") ) {
            if ( t.hasMoreTokens() ) {
                user = t.nextToken();
                if ( isValidUser(user) ) {
                    channel.sendLine(331, "Password required for " + user);
                } else
                    channel.sendLine(530, "User \"" + user + "\" unknown");
            } else
                channel.sendLine(501, "Invalid number of arguments");
            return;
        } else if ( message.equalsIgnoreCase("PASS") ) {
            if ( t.hasMoreTokens() ) {
                if ( isValidPass( t.nextToken() )) {
                    channel.sendLine(230, "Password correct. User \"" + user + "\" logged in");
                } else {
                    channel.sendLine(530, "wrong password");
                }
            } else
                channel.sendLine(501, "Invalid number of arguments");
            return;
        } else if ( message.equalsIgnoreCase("NOOP") ) {
            channel.sendLine(200, "NOOP-Command successful");
            return;
        } else if ( message.equalsIgnoreCase("LEVEL") ) {
        
        } else
            channel.sendLine(500, "Command \"" + message + "\" unknown");
    }
    
    public void initConnection() {
        channel.connect();
        channel.sendLine(220, "Welcome to MythGraphics");
    }
    
}
