/*
 * HoldThread.java
 *
 * Created on 21. Januar 2008, 21:18
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.ftp;

/*
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.1
 *
 */

public class HoldThread extends Thread {

    private ClientProtocol ftp;

    public HoldThread(ClientProtocol ftp) {
        this.ftp = ftp;
    }

    @Override
    public void run() {
        try {
            while ( !isInterrupted() ) {
                ftp.noop();
                sleep(30*1000);
            }
        } catch (InterruptedException e) {interrupt();}
    }

}
