/*
 * ProtocolInterface.java
 *
 * Created on 12. November 2009, 00:44
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net;

/**
 *
 * @author Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

public interface ProtocolInterface {
    
    void processIncommingMessage(String message);
    void processOutgoingMessage(String message);
    
}
