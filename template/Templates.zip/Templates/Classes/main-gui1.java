<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author  ${user}
 * @version 0.0.0
 *
 */

public class ${name} {

    public final static String NAME    = "MythGraphics ";                                           // TODO Name der Anwendung
    public final static String VERSION = "0.0.0";                                                   // TODO Versionsnummer

    public static void main(String[] args) {
        new ${name}(args);
    }

    private void startGUI() {
        java.awt.EventQueue.invokeLater( new Runnable() {
            public void run() {
                /* TODO hier GUI-Frame einbauen
                 * new GUIFrame1().setVisible(true);
                 */
            }
        });
    }

    public ${name}(String[] args) {
        if ( (args == null || args.length == 0) || args[0].equalsIgnoreCase("--gui") )
        {
            startGUI();
        }
        else if ( args[0].equalsIgnoreCase("--help") )
        {
            printHelp();
        }
        else if ( args[0].equalsIgnoreCase("--version") )
        {
            System.out.println(NAME + " v" + VERSION);
        }
        // TODO hier weiter
        else
        {
            System.err.println("Parameter \"" + args[0] + "\" unbekannt");
            System.out.println();
            printHelp();
        }
    }

    private static void printHelp() {
        System.out.println("Aufruf:");
        // TODO hier weiter
        System.out.println();
        System.out.println("Parameter:");
        System.out.println("  --gui         lädt das grafische Interface");
        System.out.println("  --help        zeigt diese Hilfe an");
        System.out.println("  --version     zeigt Programm-Version an");
        System.out.println();
    }

}
