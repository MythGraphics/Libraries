<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};
</#if>

/**
 *
 * @author  ${user}
 * @version 0.0.0
 *
 */

import javax.swing.JApplet;
import javax.swing.SwingUtilities;

public class ${name} extends JApplet {

    /**
     * Initialization method that will be called after the applet is loaded into the browser.
     */
    @Override
    public void init() {
        // Execute a job on the event-dispatching thread; creating this applet's GUI.
        try {
            SwingUtilities.invokeAndWait( new Runnable() {
                public void run() {
                    // TODO code application logic here
                }
            });
        } catch (Exception e) {
            System.err.println("creating the GUI didn't complete successfully");
        }
    }

    @Override
    public void start() {}

    @Override
    public void stop() {}

    @Override
    public void destroy {}

}
